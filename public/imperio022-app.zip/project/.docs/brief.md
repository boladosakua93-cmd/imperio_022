# Império 022 — App Lava Jato

- One-line positioning: Aplicativo completo para lava jato com agendamento online, catálogo de serviços e painel admin
- Target users: Clientes do lava jato + dono/funcionários do estabelecimento
- Core features:
  1. Landing page institucional com a identidade visual (preto/vermelho) do Império 022
  2. Catálogo de serviços com preços (lavagem simples, completa, polimento, cristalização, etc.)
  3. Agendamento online (data, hora, tipo de serviço, dados do veículo)
  4. Painel admin para visualizar e gerenciar agendamentos
- Important features (P1):
  1. Status de agendamento (pendente, confirmado, concluído, cancelado)
  2. Confirmação visual pós-agendamento
- Device strategy: adaptive
- Design style: Dark escuro com vermelho como cor de destaque — baseado no logo Império 022
- Technical constraints: none
- Nova Agent: not needed
- Completed: brief
- Current iteration: Build completo inicial
