# Design — Império 022

- Background: #0a0a0a (quase preto, textura escura)
- Surface: #111111
- Card: #161616
- Primary accent: #e01e1e (vermelho vibrante)
- Secondary accent: #ff3333 (vermelho mais claro para hover)
- Text primary: #FFFFFF
- Text secondary: #A0A0A0
- Text muted: #555555
- Border subtle: rgba(255,255,255,0.08)
- Border accent: rgba(224,30,30,0.5)
- Radius: 12px cards, 8px inputs, 100px pills
- Font: Inter (headings bold, tracking -1px a -2px)
- Gradient brand: linear-gradient(135deg, #e01e1e 0%, #ff6600 100%)
