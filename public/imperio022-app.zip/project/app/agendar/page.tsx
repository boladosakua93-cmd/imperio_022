"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import {
  ArrowLeft,
  Car,
  Calendar,
  Clock,
  User,
  Phone,
  CheckCircle,
  ChevronRight,
  Sparkles,
  Shield,
  Zap,
  Droplets,
  Star,
} from "lucide-react";

const services = [
  { id: "lavagem-simples", name: "Lavagem Simples", price: 30, duration: "30 min", icon: Droplets },
  { id: "lavagem-completa", name: "Lavagem Completa", price: 60, duration: "60 min", icon: Sparkles },
  { id: "polimento", name: "Polimento", price: 150, duration: "2h", icon: Shield },
  { id: "cristalizacao", name: "Cristalização", price: 200, duration: "3h", icon: Zap },
  { id: "higienizacao-interna", name: "Higienização Interna", price: 120, duration: "90 min", icon: Car },
  { id: "pacote-vip", name: "Pacote VIP", price: 420, duration: "4h", icon: Star },
];

const timeSlots = [
  "08:00", "08:30", "09:00", "09:30", "10:00", "10:30",
  "11:00", "11:30", "13:00", "13:30", "14:00", "14:30",
  "15:00", "15:30", "16:00", "16:30", "17:00", "17:30",
];

const vehicleTypes = ["Hatch", "Sedan", "SUV", "Pickup", "Van/Minivan", "Moto"];

function AgendarContent() {
  const searchParams = useSearchParams();
  const servicoParam = searchParams.get("servico");

  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState({
    servico: servicoParam || "",
    data: "",
    horario: "",
    nomeCliente: "",
    telefone: "",
    tipoVeiculo: "",
    placa: "",
    modelo: "",
    observacoes: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (servicoParam) {
      const match = services.find(s => s.name === servicoParam);
      if (match) setForm(f => ({ ...f, servico: match.id }));
    }
  }, [servicoParam]);

  const selectedService = services.find(s => s.id === form.servico);

  const getTodayStr = () => {
    const d = new Date();
    return d.toISOString().split("T")[0];
  };

  const validate = (currentStep: number): boolean => {
    const errs: Record<string, string> = {};
    if (currentStep === 1 && !form.servico) errs.servico = "Selecione um serviço.";
    if (currentStep === 2) {
      if (!form.data) errs.data = "Informe a data.";
      if (!form.horario) errs.horario = "Selecione um horário.";
    }
    if (currentStep === 3) {
      if (!form.nomeCliente.trim()) errs.nomeCliente = "Informe seu nome.";
      if (!form.telefone.trim()) errs.telefone = "Informe seu telefone.";
      if (!form.tipoVeiculo) errs.tipoVeiculo = "Selecione o tipo do veículo.";
      if (!form.modelo.trim()) errs.modelo = "Informe o modelo.";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const nextStep = () => {
    if (validate(step)) setStep(s => s + 1);
  };

  const handleSubmit = async () => {
    if (!validate(3)) return;
    setLoading(true);
    try {
      const res = await fetch("/api/agendamentos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, servicoNome: selectedService?.name, servicoPreco: selectedService?.price }),
      });
      if (res.ok) {
        setSuccess(true);
      } else {
        alert("Erro ao agendar. Tente novamente.");
      }
    } catch {
      alert("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div style={{ minHeight: "100vh", backgroundColor: "var(--background)", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
        <div style={{ maxWidth: 480, width: "100%", textAlign: "center" }}>
          <div style={{
            width: 80, height: 80, borderRadius: "50%",
            background: "rgba(224,30,30,0.1)", border: "2px solid rgba(224,30,30,0.4)",
            display: "flex", alignItems: "center", justifyContent: "center",
            margin: "0 auto 24px",
          }}>
            <CheckCircle size={40} color="#e01e1e" />
          </div>
          <h2 style={{ fontSize: 32, fontWeight: 800, letterSpacing: "-1px", marginBottom: 12 }}>
            Agendamento <span className="gradient-text">Confirmado!</span>
          </h2>
          <p style={{ color: "#A0A0A0", fontSize: 16, lineHeight: 1.7, marginBottom: 32 }}>
            Seu agendamento foi realizado com sucesso! Em breve entraremos em contato para confirmar o horário.
          </p>
          <div className="card-glow" style={{ padding: 24, marginBottom: 32, textAlign: "left" }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[
                { label: "Serviço", value: selectedService?.name },
                { label: "Data", value: new Date(form.data + "T12:00:00").toLocaleDateString("pt-BR") },
                { label: "Horário", value: form.horario },
                { label: "Nome", value: form.nomeCliente },
                { label: "Veículo", value: `${form.modelo} (${form.tipoVeiculo})` },
              ].map(row => (
                <div key={row.label} style={{ display: "flex", justifyContent: "space-between", gap: 16 }}>
                  <span style={{ color: "#555", fontSize: 14 }}>{row.label}</span>
                  <span style={{ fontWeight: 600, fontSize: 14, textAlign: "right" }}>{row.value}</span>
                </div>
              ))}
            </div>
          </div>
          <Link href="/" className="btn-primary">
            Voltar ao Início
          </Link>
        </div>
      </div>
    );
  }

  const inputStyle: React.CSSProperties = {
    background: "var(--card)",
    border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: 10,
    padding: "12px 16px",
    color: "#fff",
    fontSize: 15,
    width: "100%",
    outline: "none",
    transition: "border-color 150ms",
    boxSizing: "border-box",
  };

  const labelStyle: React.CSSProperties = {
    fontSize: 13,
    fontWeight: 600,
    color: "#A0A0A0",
    marginBottom: 8,
    display: "block",
    textTransform: "uppercase",
    letterSpacing: "0.5px",
  };

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "var(--background)", fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <div style={{
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        padding: "16px 24px",
        display: "flex",
        alignItems: "center",
        gap: 16,
        background: "rgba(10,10,10,0.95)",
        backdropFilter: "blur(12px)",
        position: "sticky", top: 0, zIndex: 10,
      }}>
        <Link href="/" style={{ color: "#A0A0A0", display: "flex", alignItems: "center", gap: 6, textDecoration: "none", fontSize: 14, fontWeight: 500 }}
          onMouseEnter={e => (e.currentTarget.style.color = "#fff")}
          onMouseLeave={e => (e.currentTarget.style.color = "#A0A0A0")}>
          <ArrowLeft size={16} /> Voltar
        </Link>
        <div style={{ flex: 1, display: "flex", justifyContent: "center" }}>
          <Image src="/logo.png" alt="Império 022" width={80} height={44} style={{ objectFit: "contain" }} />
        </div>
        <div style={{ width: 60 }} />
      </div>

      <div style={{ maxWidth: 640, margin: "0 auto", padding: "40px 24px 80px" }}>
        {/* Progress */}
        <div style={{ marginBottom: 40 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
            {["Serviço", "Data & Hora", "Seus Dados"].map((label, i) => (
              <div key={label} style={{ textAlign: "center", flex: 1 }}>
                <div style={{
                  width: 32, height: 32, borderRadius: "50%",
                  background: i + 1 < step ? "var(--gradient-brand)" : i + 1 === step ? "rgba(224,30,30,0.2)" : "rgba(255,255,255,0.05)",
                  border: i + 1 <= step ? "2px solid rgba(224,30,30,0.8)" : "2px solid rgba(255,255,255,0.1)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  margin: "0 auto 8px",
                  fontSize: 13, fontWeight: 700,
                  color: i + 1 < step ? "#fff" : i + 1 === step ? "#e01e1e" : "#555",
                  transition: "all 300ms",
                }}>
                  {i + 1 < step ? <CheckCircle size={14} /> : i + 1}
                </div>
                <div style={{ fontSize: 12, color: i + 1 === step ? "#e01e1e" : "#555", fontWeight: i + 1 === step ? 600 : 400 }}>{label}</div>
              </div>
            ))}
          </div>
          <div style={{ height: 2, background: "rgba(255,255,255,0.06)", borderRadius: 2 }}>
            <div style={{ height: "100%", width: `${((step - 1) / 2) * 100}%`, background: "var(--gradient-brand)", borderRadius: 2, transition: "width 400ms ease" }} />
          </div>
        </div>

        {/* Step 1: Serviço */}
        {step === 1 && (
          <div>
            <h2 style={{ fontSize: 28, fontWeight: 800, letterSpacing: "-0.5px", marginBottom: 8 }}>Escolha o serviço</h2>
            <p style={{ color: "#A0A0A0", marginBottom: 32 }}>Selecione qual serviço deseja agendar</p>
            {errors.servico && <div style={{ color: "#ff4444", fontSize: 13, marginBottom: 16 }}>{errors.servico}</div>}
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {services.map(s => {
                const Icon = s.icon;
                const selected = form.servico === s.id;
                return (
                  <button key={s.id} onClick={() => setForm(f => ({ ...f, servico: s.id }))}
                    style={{
                      background: selected ? "rgba(224,30,30,0.08)" : "var(--card)",
                      border: `1px solid ${selected ? "rgba(224,30,30,0.5)" : "rgba(255,255,255,0.08)"}`,
                      borderRadius: 14,
                      padding: "18px 20px",
                      display: "flex",
                      alignItems: "center",
                      gap: 16,
                      cursor: "pointer",
                      transition: "all 200ms",
                      textAlign: "left",
                      width: "100%",
                    }}>
                    <div style={{
                      width: 44, height: 44, borderRadius: 10,
                      background: selected ? "rgba(224,30,30,0.15)" : "rgba(255,255,255,0.04)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      flexShrink: 0,
                    }}>
                      <Icon size={20} color={selected ? "#e01e1e" : "#666"} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 15, color: selected ? "#fff" : "#ccc" }}>{s.name}</div>
                      <div style={{ color: "#555", fontSize: 13 }}>{s.duration}</div>
                    </div>
                    <div style={{ fontWeight: 800, fontSize: 18, letterSpacing: "-0.5px" }} className={selected ? "gradient-text" : ""}>
                      <span style={{ color: selected ? undefined : "#A0A0A0" }}>R$ {s.price}</span>
                    </div>
                    {selected && <CheckCircle size={18} color="#e01e1e" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 2: Data e Hora */}
        {step === 2 && (
          <div>
            <h2 style={{ fontSize: 28, fontWeight: 800, letterSpacing: "-0.5px", marginBottom: 8 }}>Data e Horário</h2>
            <p style={{ color: "#A0A0A0", marginBottom: 32 }}>Quando deseja trazer seu veículo?</p>
            <div style={{ marginBottom: 28 }}>
              <label style={labelStyle}>Data</label>
              <input
                type="date"
                value={form.data}
                min={getTodayStr()}
                onChange={e => setForm(f => ({ ...f, data: e.target.value }))}
                style={{ ...inputStyle, borderColor: errors.data ? "#ff4444" : undefined, colorScheme: "dark" }}
              />
              {errors.data && <div style={{ color: "#ff4444", fontSize: 12, marginTop: 6 }}>{errors.data}</div>}
            </div>
            <div>
              <label style={labelStyle}>Horário disponível</label>
              {errors.horario && <div style={{ color: "#ff4444", fontSize: 12, marginBottom: 8 }}>{errors.horario}</div>}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
                {timeSlots.map(t => {
                  const sel = form.horario === t;
                  return (
                    <button key={t} onClick={() => setForm(f => ({ ...f, horario: t }))}
                      style={{
                        padding: "12px 8px",
                        borderRadius: 10,
                        border: `1px solid ${sel ? "rgba(224,30,30,0.6)" : "rgba(255,255,255,0.08)"}`,
                        background: sel ? "rgba(224,30,30,0.1)" : "var(--card)",
                        color: sel ? "#e01e1e" : "#A0A0A0",
                        fontSize: 14,
                        fontWeight: sel ? 700 : 400,
                        cursor: "pointer",
                        transition: "all 150ms",
                      }}>
                      {t}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Dados do cliente */}
        {step === 3 && (
          <div>
            <h2 style={{ fontSize: 28, fontWeight: 800, letterSpacing: "-0.5px", marginBottom: 8 }}>Seus dados</h2>
            <p style={{ color: "#A0A0A0", marginBottom: 32 }}>Preencha seus dados para finalizar</p>

            <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div>
                  <label style={labelStyle}><User size={12} style={{ display: "inline", marginRight: 4 }} />Nome *</label>
                  <input placeholder="Seu nome completo" value={form.nomeCliente}
                    onChange={e => setForm(f => ({ ...f, nomeCliente: e.target.value }))}
                    style={{ ...inputStyle, borderColor: errors.nomeCliente ? "#ff4444" : undefined }} />
                  {errors.nomeCliente && <div style={{ color: "#ff4444", fontSize: 12, marginTop: 4 }}>{errors.nomeCliente}</div>}
                </div>
                <div>
                  <label style={labelStyle}><Phone size={12} style={{ display: "inline", marginRight: 4 }} />Telefone *</label>
                  <input placeholder="(00) 00000-0000" value={form.telefone}
                    onChange={e => setForm(f => ({ ...f, telefone: e.target.value }))}
                    style={{ ...inputStyle, borderColor: errors.telefone ? "#ff4444" : undefined }} />
                  {errors.telefone && <div style={{ color: "#ff4444", fontSize: 12, marginTop: 4 }}>{errors.telefone}</div>}
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div>
                  <label style={labelStyle}><Car size={12} style={{ display: "inline", marginRight: 4 }} />Tipo do Veículo *</label>
                  <select value={form.tipoVeiculo}
                    onChange={e => setForm(f => ({ ...f, tipoVeiculo: e.target.value }))}
                    style={{ ...inputStyle, borderColor: errors.tipoVeiculo ? "#ff4444" : undefined }}>
                    <option value="">Selecione...</option>
                    {vehicleTypes.map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                  {errors.tipoVeiculo && <div style={{ color: "#ff4444", fontSize: 12, marginTop: 4 }}>{errors.tipoVeiculo}</div>}
                </div>
                <div>
                  <label style={labelStyle}>Modelo *</label>
                  <input placeholder="Ex: Honda Civic" value={form.modelo}
                    onChange={e => setForm(f => ({ ...f, modelo: e.target.value }))}
                    style={{ ...inputStyle, borderColor: errors.modelo ? "#ff4444" : undefined }} />
                  {errors.modelo && <div style={{ color: "#ff4444", fontSize: 12, marginTop: 4 }}>{errors.modelo}</div>}
                </div>
              </div>
              <div>
                <label style={labelStyle}>Placa (opcional)</label>
                <input placeholder="ABC-1234" value={form.placa}
                  onChange={e => setForm(f => ({ ...f, placa: e.target.value.toUpperCase() }))}
                  style={inputStyle} maxLength={8} />
              </div>
              <div>
                <label style={labelStyle}>Observações (opcional)</label>
                <textarea placeholder="Alguma informação importante sobre o veículo..." value={form.observacoes}
                  onChange={e => setForm(f => ({ ...f, observacoes: e.target.value }))}
                  style={{ ...inputStyle, minHeight: 90, resize: "vertical" }} />
              </div>
            </div>

            {/* Resumo */}
            {selectedService && (
              <div className="card-glow" style={{ marginTop: 28, padding: 20 }}>
                <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.5px", color: "#e01e1e", marginBottom: 12 }}>
                  Resumo do Agendamento
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {[
                    { label: "Serviço", value: selectedService.name },
                    { label: "Data", value: form.data ? new Date(form.data + "T12:00:00").toLocaleDateString("pt-BR") : "—" },
                    { label: "Horário", value: form.horario || "—" },
                    { label: "Valor", value: `R$ ${selectedService.price}` },
                  ].map(row => (
                    <div key={row.label} style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ color: "#555", fontSize: 14 }}>{row.label}</span>
                      <span style={{ fontWeight: 600, fontSize: 14 }}>{row.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Navigation buttons */}
        <div style={{ marginTop: 40, display: "flex", gap: 12, justifyContent: "space-between" }}>
          {step > 1 ? (
            <button onClick={() => setStep(s => s - 1)} className="btn-outline" style={{ padding: "13px 24px" }}>
              <ArrowLeft size={16} /> Voltar
            </button>
          ) : <div />}

          {step < 3 ? (
            <button onClick={nextStep} className="btn-primary">
              Continuar <ChevronRight size={18} />
            </button>
          ) : (
            <button onClick={handleSubmit} className="btn-primary" disabled={loading}
              style={{ opacity: loading ? 0.7 : 1, cursor: loading ? "not-allowed" : "pointer" }}>
              {loading ? "Agendando..." : "Confirmar Agendamento"} <CheckCircle size={18} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default function AgendarPage() {
  return (
    <Suspense fallback={
      <div style={{ minHeight: "100vh", backgroundColor: "var(--background)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ color: "#A0A0A0" }}>Carregando...</div>
      </div>
    }>
      <AgendarContent />
    </Suspense>
  );
}
